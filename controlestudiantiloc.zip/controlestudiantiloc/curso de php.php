<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1>strtolower <small>Minuscilas</small></h1>
<h1>strtoupper <small>Minuscilas</small></h1>
strlen
unlink() 
<h1></h1>

</body>
</html>

<?php strtoupper(string) ?>
