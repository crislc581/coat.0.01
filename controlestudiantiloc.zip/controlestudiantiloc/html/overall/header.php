
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="author" content="Reservado con todos los derechos">
    <!-- <base href=""> -->
    <!-- <base href="<?php //echo APP_URL; ?>"> -->
    <!-- evitar hacer injecciones java script -->


    <!-- Bootstrap core CSS -->
    <link href="view/admin/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="view/admin/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- Plugin CSS -->
    <link href="view/admin/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <link href="view/frameworks/animate.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="view/admin/css/sb-admin.css" rel="stylesheet">

    <!-- mi boostrarp -->
    <link rel="stylesheet" type="text/css" href="view/admin/vendor/bootstrap/css/miboostratp.css">
    <link rel="stylesheet" href="view/frameworks/sweetalert-master/dist/sweetalert.css">
    <link rel="stylesheet" href="view/app/css/styles-navbar.css">
    <script src="view/app/js/generales.js"></script>
        <script src="view/admin/vendor/jquery/jquery.min.js"></script>


<!-- $sql = "SELECT * FROM 0014amatriculados INNER JOIN iii" -->