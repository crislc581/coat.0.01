<footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
        <div class="row">
        <div class="col-md-4">
          <small>Copyright &copy; COACO 2017 </small>
        </div>
        <div class="col-md-4">
          <small>Actualizado 06/12/2017</small>
        </div>
        <div class="col-md-4">
          <small>Teléfono: 3148554726 , 3212913171</small>
        </div>
        </div>
          
        </div>
      </div>
    </footer>

    <!-- Scroll to Top Button -->
    <!-- fecla para subir al principio de la ágona -->
    <a class="scroll-to-top rounded" href="#page-top" style="z-index:1000;">
      <i class="fa fa-angle-up"></i>
    </a>