<!DOCTYPE html>
<html lang="en">

  <head>
    <?php include(OVERALL.'header.php'); ?>
    <title>Regisrtrar alumno</title>
   
    
  </head>
  <body class="fixed-nav sticky-footer bg-dark" id="page-top">
  	<!-- Navigation Barra de navegacion horizontal y vertical-->
    <?php include(OVERALL.'navbar.php'); ?>

    <div class="content-wrapper">
      	<div class="container-fluid">

	        <!-- Breadcrumbs -->
	        <!-- migas de pan -->
	        <ol class="breadcrumb">
	          <li class="breadcrumb-item">
	            <a href="#">Inicio</a>
	          </li>
	          <li class="breadcrumb-item active">Mis informes</li>
	        </ol>

	        
    	</div>
    </div>


  	<?php include(OVERALL.'footer.html'); ?>

  </body>
</html>