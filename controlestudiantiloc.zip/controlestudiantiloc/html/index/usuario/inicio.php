<h2>Bienvvenido usaurio</h2>

<a class="btn btn-primary" href="?view=cerrarsesion">Cerrar Sesión</a>
