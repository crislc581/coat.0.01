<?php 

	if (isset($_SESSION['usuario'])) {
		include(HIUSU.'inicio.php');
	}else{
		header('Location: ?view=inicioindex');
	}

 ?>