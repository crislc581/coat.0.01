<?php
if (isset($_SESSION['usuario'][0])) {
	header('location: ?view=superinicio');
}else if(isset($_SESSION['secretaria'])){
	header('location: ?view=secretariainicio');
}else if(isset($_SESSION['profesor'])){
	header('location: ?view=profesorinicio');
}else if(isset($_SESSION['usuario'])){
	header('location: ?view=usuarioinicio');
}else{
	// entra aca
	// header('location: ?view=inicioindex');
	include(HIINICIO.'index.php');
}

 ?>3125768655
