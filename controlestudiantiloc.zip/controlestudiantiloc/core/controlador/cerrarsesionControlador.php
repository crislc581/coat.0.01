<?php 


if (isset($_SESSION['usuario'][0])) {
	unset($_SESSION['usuario'][0]);
	header('location: ?view=inicioindex');
}else if(isset($_SESSION['secretaria'])){
	unset($_SESSION['secretaria']);
	header('location: ?view=inicioindex');
}else if(isset($_SESSION['profesor'])){
	unset($_SESSION['profesor']);
	header('location: ?view=inicioindex');
}else if(isset($_SESSION['usuario'])){
	unset($_SESSION['usuario']);
	header('location: ?view=inicioindex');
}



 ?>

